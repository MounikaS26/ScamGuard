# data/db.py
import sqlite3, os, datetime

BASE_DIR = os.path.dirname(os.path.dirname(__file__))  # project root
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "scamguard.db")

os.makedirs(DATA_DIR, exist_ok=True)

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS prediction_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            text_excerpt TEXT NOT NULL,
            prediction_label TEXT NOT NULL,
            confidence REAL,
            created_at TEXT NOT NULL
        )
        """)
        conn.commit()

def insert_log(user_id: str, text_excerpt: str, prediction_label: str, confidence: float | None):
    if not text_excerpt:
        text_excerpt = "(empty)"
    text_excerpt = text_excerpt.strip().replace("\x00","")[:250]  # safety + limit
    ts = datetime.datetime.utcnow().isoformat(timespec="seconds") + "Z"
    with get_db() as conn:
        conn.execute("""
            INSERT INTO prediction_logs (user_id, text_excerpt, prediction_label, confidence, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (str(user_id), text_excerpt, prediction_label, confidence, ts))
        conn.commit()

def fetch_logs(user_id: str, limit: int = 200):
    with get_db() as conn:
        cur = conn.execute("""
            SELECT id, text_excerpt, prediction_label, confidence, created_at
            FROM prediction_logs
            WHERE user_id = ?
            ORDER BY id DESC
            LIMIT ?
        """, (str(user_id), int(limit)))
        return cur.fetchall()

def delete_log(user_id: str, log_id: int) -> int:
    """Delete a single log that belongs to this user. Returns rows affected (0 or 1)."""
    with get_db() as conn:
        cur = conn.execute(
            "DELETE FROM prediction_logs WHERE id = ? AND user_id = ?",
            (int(log_id), str(user_id)),
        )
        conn.commit()
        return cur.rowcount